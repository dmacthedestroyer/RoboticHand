// $Id: NapkinKnownTheme.java 383 2006-03-16 22:45:13Z alexlamsl $

package net.sourceforge.napkinlaf;

public enum NapkinKnownTheme {
    BASIC_THEME, POPUP_THEME,
}