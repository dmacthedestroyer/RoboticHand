// $Id: NapkinThemeColor.java 383 2006-03-16 22:45:13Z alexlamsl $

package net.sourceforge.napkinlaf;

public enum NapkinThemeColor {
    PEN_COLOR,
    CHECK_COLOR,
    RADIO_COLOR,
    HIGHLIGHT_COLOR,
    SELECTION_COLOR,
    BACKGROUND_COLOR,
}