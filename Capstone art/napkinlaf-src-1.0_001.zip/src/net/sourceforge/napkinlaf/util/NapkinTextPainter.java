// $Id: NapkinTextPainter.java 383 2006-03-16 22:45:13Z alexlamsl $

package net.sourceforge.napkinlaf.util;

import javax.swing.*;
import java.awt.*;

public interface NapkinTextPainter {
    void superPaintText(Graphics g, JComponent c, Rectangle textRect,
            String text);
}
