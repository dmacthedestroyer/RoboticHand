// $Id: NapkinPainter.java 383 2006-03-16 22:45:13Z alexlamsl $

package net.sourceforge.napkinlaf.util;

import net.sourceforge.napkinlaf.NapkinTheme;

import javax.swing.*;
import java.awt.*;

public interface NapkinPainter {
    void superPaint(Graphics g, JComponent c, NapkinTheme theme);
}