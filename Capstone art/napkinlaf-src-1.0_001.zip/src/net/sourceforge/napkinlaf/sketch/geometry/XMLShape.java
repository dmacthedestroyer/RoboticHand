// $Id: XMLShape.java 383 2006-03-16 22:45:13Z alexlamsl $

package net.sourceforge.napkinlaf.sketch.geometry;

import org.jdom.Element;

/**
 * @author Peter Goodspeed
 * @author Justin Crafford
 */
public interface XMLShape extends SketchShape {
    /** @return the XML representation of this Shape. */
    Element produceXML();
}
