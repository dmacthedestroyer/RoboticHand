// $Id: TemplateReadException.java 383 2006-03-16 22:45:13Z alexlamsl $

package net.sourceforge.napkinlaf.sketch;

/**
 * Thrown when there is an exception while trying to read a <tt>Template</tt>.
 *
 * @author Peter Goodspeed
 */
public class TemplateReadException extends Exception {
    public TemplateReadException(Throwable cause) {
        super(cause);
    }
}
