These are the screen snapshots used on sourceforge for the project.  They are
scaled-down images of the site's snapshots.
