This file tells you how to run SwingSet, both as an applet and
as an application.  

These instructions assume that this installation's versions of the java
and appletviewer commands are in your path.  If they aren't,
then you should either specify the complete path to the commands
or update your PATH environment variable as described in the
installation instructions for the Java 2 SDK.


=================================
TO RUN SWINGSET AS AN APPLICATION
=================================

  java -jar SwingSet2.jar


============================
TO RUN SWINGSET AS AN APPLET
============================

  appletviewer SwingSet2.html
 
